﻿namespace usersignup
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            borrowerToolStripMenuItem = new ToolStripMenuItem();
            booksToolStripMenuItem = new ToolStripMenuItem();
            reportToolStripMenuItem = new ToolStripMenuItem();
            logOutToolStripMenuItem = new ToolStripMenuItem();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ControlText;
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, reportToolStripMenuItem, logOutToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.BackColor = SystemColors.ControlText;
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { borrowerToolStripMenuItem, booksToolStripMenuItem });
            fileToolStripMenuItem.ForeColor = Color.Yellow;
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // borrowerToolStripMenuItem
            // 
            borrowerToolStripMenuItem.BackColor = SystemColors.ControlText;
            borrowerToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            borrowerToolStripMenuItem.Name = "borrowerToolStripMenuItem";
            borrowerToolStripMenuItem.Size = new Size(180, 22);
            borrowerToolStripMenuItem.Text = "Borrower";
            borrowerToolStripMenuItem.Click += borrowerToolStripMenuItem_Click;
            // 
            // booksToolStripMenuItem
            // 
            booksToolStripMenuItem.BackColor = SystemColors.ControlText;
            booksToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            booksToolStripMenuItem.Name = "booksToolStripMenuItem";
            booksToolStripMenuItem.Size = new Size(180, 22);
            booksToolStripMenuItem.Text = "Books";
            booksToolStripMenuItem.Click += booksToolStripMenuItem_Click;
            // 
            // reportToolStripMenuItem
            // 
            reportToolStripMenuItem.BackColor = SystemColors.ControlText;
            reportToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            reportToolStripMenuItem.Size = new Size(54, 20);
            reportToolStripMenuItem.Text = "Report";
            reportToolStripMenuItem.Click += reportToolStripMenuItem_Click;
            // 
            // logOutToolStripMenuItem
            // 
            logOutToolStripMenuItem.BackColor = SystemColors.ControlText;
            logOutToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            logOutToolStripMenuItem.Size = new Size(60, 20);
            logOutToolStripMenuItem.Text = "Log out";
            logOutToolStripMenuItem.Click += logOutToolStripMenuItem_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(241, 71);
            label6.Name = "label6";
            label6.Size = new Size(303, 47);
            label6.TabIndex = 6;
            label6.Text = "Welcome Admin!";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources._5146394;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(241, 133);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(303, 280);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlText;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(label6);
            Controls.Add(menuStrip1);
            ForeColor = Color.FromArgb(255, 255, 128);
            MainMenuStrip = menuStrip1;
            Name = "home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home Admin";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem borrowerToolStripMenuItem;
        private ToolStripMenuItem booksToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem;
        private ToolStripMenuItem logOutToolStripMenuItem;
        private Label label6;
        private PictureBox pictureBox1;
    }
}