﻿using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace usersignup
{
    public partial class Report : Form
    {
        Thread HomeFromReport, report, logout;
        //private DataGridViewPrinter dataGridViewPrinter;
        public Report()
        {
            InitializeComponent();
            // dataGridViewPrinter = new DataGridViewPrinter(dataGridView1);
        }
        public void LogoutAdmin(object obj)
        {
            Application.Run(new Login());
        }
        public void BackHome(object obj)
        {
            Application.Run(new home());
        }
        public void GoToReport(object obj)
        {
            Application.Run(new Report());
        }
        private void loadDatagrid()
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT Backup_Records.username, CONCAT(firstname, ' ', lastname) AS Name," +
                    " Backup_Records.Accession_number, Backup_Records.Title,\r\nBackup_Records.Date_Borrowed," +
                    " Backup_Records_Returned_Date.Returned_Date  \r\nFROM Backup_Records \r\nINNER JOIN Backup_Records_Returned_Date \r\nON Backup_Records.username = Backup_Records_Returned_Date.username;", con);

                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                dataGridView1.DataSource = tab;

                con.Close();
            }


        }

        private void Report_Load(object sender, EventArgs e)
        {
            loadDatagrid();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT Backup_Records.username, CONCAT(firstname, ' ', lastname) AS Name, Backup_Records.Accession_number, Backup_Records.Title,\r\nBackup_Records.Date_Borrowed," +
                    " Backup_Records_Returned_Date.Returned_Date  \r\nFROM Backup_Records \r\nINNER JOIN Backup_Records_Returned_Date \r\nON Backup_Records.username = Backup_Records_Returned_Date.username where Accession_number like'%" + txtSearch.Text + "%'", con);


                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                dataGridView1.DataSource = tab;

                con.Close();

            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            HomeFromReport = new Thread(BackHome);
            HomeFromReport.SetApartmentState(ApartmentState.STA);
            HomeFromReport.Start();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            this.dataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }


        private void printbutton_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.DocumentName = "DataGridView Print";
            printDoc.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            PrintPreviewDialog printPreviewDlg = new PrintPreviewDialog();
            printPreviewDlg.Document = printDoc;

            if (printPreviewDlg.ShowDialog() == DialogResult.OK)
            {
                printDoc.Print();
            }
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            report = new Thread(GoToReport);
            report.SetApartmentState(ApartmentState.STA);
            report.Start();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            logout = new Thread(LogoutAdmin);
            logout.SetApartmentState(ApartmentState.STA);
            logout.Start();
        }
    }
}