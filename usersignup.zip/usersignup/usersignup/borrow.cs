﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NPOI.HPSF;
using System.Data.Sql;
using System.Data.SqlClient;
using Microsoft.VisualBasic;
using System.Globalization;
using System.Data.SqlTypes;

namespace usersignup
{
    public partial class borrow : Form
    {
        Thread exthome;
        public borrow()
        {
            InitializeComponent();
        }

        public void ext_home(object obj)
        {
            Application.Run(new homeuser());
        }
        private void borrow_Load(object sender, EventArgs e)
        {
            loadDatagrid();
        }
        private void loadDatagrid()
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select book_id, Accession_number, Title, Author, quantity, Year_Published from books where quantity >= 1", con);

                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                grid1.DataSource = tab;

                con.Close();
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select * from books where Title like'%" + txtSearch.Text + "%' and quantity >= 1", con);

                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                grid1.DataSource = tab;

                con.Close();
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            exthome = new Thread(ext_home);
            exthome.SetApartmentState(ApartmentState.STA);
            exthome.Start();

        }

        private void btnborrow_Click(object sender, EventArgs e)
        {

            if (txtusername.Text != "" && txtfirstname.Text != "" && txtlastname.Text != "" && txtdate.Text != "" && txtaccessionnumber.Text != "")
            {
                // Check if book is available
                int quantity = 0;
                using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
                {
                    con.Open();
                    SqlCommand com = new SqlCommand("SELECT quantity FROM books WHERE Accession_number = '" + txtaccessionnumber.Text + "'", con);
                    SqlDataReader reader = com.ExecuteReader();
                    if (reader.Read())
                    {
                        quantity = int.Parse(reader["quantity"].ToString());
                    }
                    reader.Close();
                }

                if (quantity <= 0)
                {
                    MessageBox.Show("Book is not available for borrowing.");
                    return;
                }

                // Borrow the book
                using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
                {

                    con.Open();

                    SqlCommand CheckifExist = new SqlCommand();
                    CheckifExist.CommandText = "Select * from borrower_info where username = '" + txtusername.Text + "'";
                    CheckifExist.Parameters.AddWithValue("@username", txtusername.Text);
                    CheckifExist.Connection = con;
                    con.Close();
                    con.Open();
                    SqlDataReader dt = CheckifExist.ExecuteReader();
                    if (dt.HasRows)
                    {
                        MessageBox.Show("You cannot borrow multiple times!");
                        con.Close();
                    }
                    else
                    {
                        con.Close();
                        con.Open();
                        SqlCommand insertBorrower = new SqlCommand("INSERT INTO borrower_info(username,firstname,lastname,date) VALUES('" + txtusername.Text + "','" + txtfirstname.Text + "','" + txtlastname.Text + "','" + txtdate.Value.ToString("yyyy-MM-dd") + "')", con);
                        insertBorrower.ExecuteNonQuery();

                        String username = txtusername.Text;
                        SqlCommand insertBorrowedBook = new SqlCommand("INSERT INTO books_borrowed(username, Accession_number,Title,Author,Year_Published) VALUES('" + username + "','" + txtaccessionnumber.Text + "','" + txttitle.Text + "','" + txtauthor.Text + "','" + txtyrpublished.Text + "')", con);
                        insertBorrowedBook.ExecuteNonQuery();

                        SqlCommand insertBackup_Recovery = new SqlCommand("INSERT INTO Backup_Records(username, firstname, lastname, Accession_number, Title, Date_Borrowed) VALUES(@username, @firstname, @lastname, @accession_number, @title, @date_borrowed)", con);
                        insertBackup_Recovery.Parameters.AddWithValue("@username", txtusername.Text);
                        insertBackup_Recovery.Parameters.AddWithValue("@firstname", txtfirstname.Text);
                        insertBackup_Recovery.Parameters.AddWithValue("@lastname", txtlastname.Text);
                        insertBackup_Recovery.Parameters.AddWithValue("@accession_number", txtaccessionnumber.Text);
                        insertBackup_Recovery.Parameters.AddWithValue("@title", txttitle.Text);
                        insertBackup_Recovery.Parameters.AddWithValue("@date_borrowed", txtdate.Value.ToString("yyyy-MM-dd"));


                        insertBackup_Recovery.ExecuteNonQuery();


                        SqlCommand updateQuantity = new SqlCommand("UPDATE books SET quantity = quantity - 1 WHERE Accession_number = '" + txtaccessionnumber.Text + "'", con);
                        updateQuantity.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Success!", "Borrowed Successfullys", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // MessageBox.Show("Book has been borrowed successfully.");
                    loadDatagrid();
                }
            }
            else
            {
                MessageBox.Show("Please fill up all the required information.");
            }
        }

        private void grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.grid1.Rows[e.RowIndex];

                txtaccessionnumber.Text = row.Cells["Accession_number"].Value.ToString();
                txttitle.Text = row.Cells["Title"].Value.ToString();
                txtauthor.Text = row.Cells["Author"].Value.ToString();
                txtyrpublished.Text = row.Cells["Year_Published"].Value.ToString();
            }
        }
    }
}