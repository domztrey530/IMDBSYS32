﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using NPOI.HPSF;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;

namespace usersignup
{
    public partial class forgotpass : Form
    {
        Thread th;
        public forgotpass()
        {
            InitializeComponent();
        }

        public void backatone(object obj)
        {
            Application.Run(new Login());
        }
        public static string Encrypt(string encryptString)
        {
            string EncryptionKey = "0ram@1234xxxxxxxxxxtttttuuuuuiiiiio";  //we can change the code converstion key as per our requirement    
            byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    encryptString = Convert.ToBase64String(ms.ToArray());
                }
            }
            return encryptString;
        }


        private void btnreset_Click(object sender, EventArgs e)
        {
            var input = txtrstnewpass.Text;

            if (input == "")
            {
                MessageBox.Show("Password required!");
                return;
            }

            var hasnumber = new Regex(@"[0-9]+");
            var hasUpper = new Regex(@"[A-Z]+");
            var hasLower = new Regex(@"[a-z]+");
            var hasChar = new Regex(@"[!@#$%^&*()_,?/|+=]+");


            if (!hasnumber.IsMatch(input))
            {
                MessageBox.Show("Password must contain numeric!");
            }
            else if (!hasUpper.IsMatch(input))
            {
                MessageBox.Show("Password must contain one upper case");
            }
            else if (!hasLower.IsMatch(input))
            {
                MessageBox.Show("Password must contain one lower case");
            }
            else if (!hasChar.IsMatch(input))
            {
                MessageBox.Show("Password must contain one special character");
            }
            else if (txtrstnewpass.Text.Length <= 7)
            {
                MessageBox.Show("Password must be 8 character or more long!");
            }
            else if (txtrstconpass.Text != txtrstnewpass.Text)
            {
                MessageBox.Show("Password unmatched!");

            }
            else if (txtrstconpass.Text == txtrstnewpass.Text)
            {
                SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True");
                SqlCommand CheckifExist = new SqlCommand();
                CheckifExist.CommandText = "Select * from [dbo].[register] where username = @username";
                CheckifExist.Parameters.AddWithValue("@username", txtrstuname.Text);
                CheckifExist.Connection = con;
                con.Open();
                SqlDataReader dt = CheckifExist.ExecuteReader();

                if (txtrstuname.Text == "" && txtrstnewpass.Text == "" && txtrstconpass.Text == "")
                {
                    MessageBox.Show("Fields must be filled", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (!dt.HasRows)
                {
                    MessageBox.Show("User not found", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (dt.HasRows)
                {
                    dt.Close(); // Close the SqlDataReader before executing the update query
                    SqlCommand changePassword = new SqlCommand("UPDATE [dbo].[register] SET [password] = @newpassword WHERE [username] = @username", con);
                    changePassword.Parameters.AddWithValue("@newpassword", Encrypt(txtrstnewpass.Text));
                    changePassword.Parameters.AddWithValue("@username", txtrstuname.Text);
                    changePassword.ExecuteNonQuery();
                    con.Close();

                    if (txtrstconpass.Text != txtrstnewpass.Text)
                    {
                        MessageBox.Show("Password does not match!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Password Successfully Changed!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void chkshow3_CheckedChanged(object sender, EventArgs e)
        {

            if (chkshow3.Checked == true)
            {
                txtrstnewpass.UseSystemPasswordChar = false;
            }
            else
                txtrstnewpass.UseSystemPasswordChar = true;
        }

        private void chkshow4_CheckedChanged(object sender, EventArgs e)
        {

            if (chkshow4.Checked == true)
            {
                txtrstconpass.UseSystemPasswordChar = false;
            }
            else
                txtrstconpass.UseSystemPasswordChar = true;
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(backatone);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
    }
}


