﻿namespace usersignup
{
    partial class Return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            txtaccessionnumber = new TextBox();
            txttitle = new TextBox();
            txtauthor = new TextBox();
            txtyrpublished = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            menuStrip1 = new MenuStrip();
            homeToolStripMenuItem = new ToolStripMenuItem();
            logOutToolStripMenuItem = new ToolStripMenuItem();
            btnreturn = new Button();
            label6 = new Label();
            label7 = new Label();
            txtusername = new TextBox();
            txtfirstname = new TextBox();
            label8 = new Label();
            label11 = new Label();
            label9 = new Label();
            label10 = new Label();
            txtlastname = new TextBox();
            return_date = new DateTimePicker();
            groupBox1 = new GroupBox();
            Bookinfo = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            Bookinfo.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(48, 59);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(694, 312);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(255, 255, 128);
            label1.Location = new Point(48, 24);
            label1.Name = "label1";
            label1.Size = new Size(187, 32);
            label1.TabIndex = 1;
            label1.Text = "Borrowed books";
            // 
            // txtaccessionnumber
            // 
            txtaccessionnumber.Location = new Point(117, 43);
            txtaccessionnumber.Name = "txtaccessionnumber";
            txtaccessionnumber.Size = new Size(212, 23);
            txtaccessionnumber.TabIndex = 2;
            // 
            // txttitle
            // 
            txttitle.Location = new Point(117, 85);
            txttitle.Name = "txttitle";
            txttitle.Size = new Size(212, 23);
            txttitle.TabIndex = 2;
            // 
            // txtauthor
            // 
            txtauthor.Location = new Point(117, 127);
            txtauthor.Name = "txtauthor";
            txtauthor.Size = new Size(212, 23);
            txtauthor.TabIndex = 2;
            // 
            // txtyrpublished
            // 
            txtyrpublished.Location = new Point(117, 171);
            txtyrpublished.Name = "txtyrpublished";
            txtyrpublished.Size = new Size(212, 23);
            txtyrpublished.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 46);
            label2.Name = "label2";
            label2.Size = new Size(107, 15);
            label2.TabIndex = 3;
            label2.Text = "Accession Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(82, 90);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 3;
            label3.Text = "Title";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(67, 130);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 3;
            label4.Text = "Author";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 174);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 3;
            label5.Text = "Year Published";
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ControlText;
            menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem, logOutToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(785, 24);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.BackColor = SystemColors.ControlText;
            homeToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(52, 20);
            homeToolStripMenuItem.Text = "Home";
            homeToolStripMenuItem.Click += homeToolStripMenuItem_Click;
            // 
            // logOutToolStripMenuItem
            // 
            logOutToolStripMenuItem.BackColor = SystemColors.ControlText;
            logOutToolStripMenuItem.ForeColor = Color.FromArgb(255, 255, 128);
            logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            logOutToolStripMenuItem.Size = new Size(60, 20);
            logOutToolStripMenuItem.Text = "Log out";
            logOutToolStripMenuItem.Click += logOutToolStripMenuItem_Click;
            // 
            // btnreturn
            // 
            btnreturn.BackColor = SystemColors.ControlText;
            btnreturn.ForeColor = Color.FromArgb(255, 255, 128);
            btnreturn.Location = new Point(646, 722);
            btnreturn.Name = "btnreturn";
            btnreturn.Size = new Size(96, 44);
            btnreturn.TabIndex = 5;
            btnreturn.Text = "Return";
            btnreturn.UseVisualStyleBackColor = false;
            btnreturn.Click += btnreturn_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(255, 255, 128);
            label6.Location = new Point(405, 387);
            label6.Name = "label6";
            label6.Size = new Size(158, 25);
            label6.TabIndex = 6;
            label6.Text = "Book Information";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(255, 255, 128);
            label7.Location = new Point(48, 387);
            label7.Name = "label7";
            label7.Size = new Size(202, 25);
            label7.TabIndex = 6;
            label7.Text = "Borrowers Information";
            // 
            // txtusername
            // 
            txtusername.Location = new Point(76, 43);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(215, 23);
            txtusername.TabIndex = 7;
            // 
            // txtfirstname
            // 
            txtfirstname.Location = new Point(76, 82);
            txtfirstname.Name = "txtfirstname";
            txtfirstname.Size = new Size(215, 23);
            txtfirstname.TabIndex = 7;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(10, 46);
            label8.Name = "label8";
            label8.Size = new Size(60, 15);
            label8.TabIndex = 8;
            label8.Text = "Username";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(1, 174);
            label11.Name = "label11";
            label11.Size = new Size(69, 15);
            label11.TabIndex = 8;
            label11.Text = "Return Date";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 85);
            label9.Name = "label9";
            label9.Size = new Size(64, 15);
            label9.TabIndex = 9;
            label9.Text = "First Name";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(7, 130);
            label10.Name = "label10";
            label10.Size = new Size(63, 15);
            label10.TabIndex = 10;
            label10.Text = "Last Name";
            // 
            // txtlastname
            // 
            txtlastname.Location = new Point(76, 127);
            txtlastname.Name = "txtlastname";
            txtlastname.Size = new Size(213, 23);
            txtlastname.TabIndex = 11;
            // 
            // return_date
            // 
            return_date.Location = new Point(76, 174);
            return_date.Name = "return_date";
            return_date.Size = new Size(215, 23);
            return_date.TabIndex = 12;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(return_date);
            groupBox1.Controls.Add(txtusername);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(txtlastname);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(txtfirstname);
            groupBox1.ForeColor = Color.FromArgb(255, 255, 128);
            groupBox1.Location = new Point(48, 415);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(332, 274);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Borrower";
            // 
            // Bookinfo
            // 
            Bookinfo.Controls.Add(label2);
            Bookinfo.Controls.Add(txtaccessionnumber);
            Bookinfo.Controls.Add(txttitle);
            Bookinfo.Controls.Add(label3);
            Bookinfo.Controls.Add(txtauthor);
            Bookinfo.Controls.Add(label5);
            Bookinfo.Controls.Add(label4);
            Bookinfo.Controls.Add(txtyrpublished);
            Bookinfo.ForeColor = Color.FromArgb(255, 255, 128);
            Bookinfo.Location = new Point(405, 415);
            Bookinfo.Name = "Bookinfo";
            Bookinfo.Size = new Size(337, 274);
            Bookinfo.TabIndex = 14;
            Bookinfo.TabStop = false;
            Bookinfo.Text = "Bookinfo";
            // 
            // Return
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlText;
            ClientSize = new Size(785, 808);
            Controls.Add(Bookinfo);
            Controls.Add(groupBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(btnreturn);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Return";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Return";
            Load += borrowed_books_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            Bookinfo.ResumeLayout(false);
            Bookinfo.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private TextBox txtaccessionnumber;
        private TextBox txttitle;
        private TextBox txtauthor;
        private TextBox txtyrpublished;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem homeToolStripMenuItem;
        private Button btnreturn;
        private Label label6;
        private Label label7;
        private TextBox txtusername;
        private TextBox txtfirstname;
        private Label label8;
        private Label label11;
        private Label label9;
        private Label label10;
        private TextBox txtlastname;
        private DateTimePicker return_date;
        private ToolStripMenuItem logOutToolStripMenuItem;
        private GroupBox groupBox1;
        private GroupBox Bookinfo;
    }
}