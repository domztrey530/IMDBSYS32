﻿namespace usersignup
{
    partial class borrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtSearch = new TextBox();
            label3 = new Label();
            grid1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtusername = new TextBox();
            txtfirstname = new TextBox();
            txtlastname = new TextBox();
            label9 = new Label();
            label10 = new Label();
            txtaccessionnumber = new TextBox();
            txttitle = new TextBox();
            txtauthor = new TextBox();
            label11 = new Label();
            label12 = new Label();
            txtyrpublished = new TextBox();
            label13 = new Label();
            btnborrow = new Button();
            menuStrip1 = new MenuStrip();
            homeToolStripMenuItem = new ToolStripMenuItem();
            txtdate = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)grid1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(618, 249);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(169, 32);
            label1.TabIndex = 0;
            label1.Text = "Borrow a book";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(44, 23);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(191, 37);
            label2.TabIndex = 1;
            label2.Text = "Borrow a book";
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.Location = new Point(95, 62);
            txtSearch.Margin = new Padding(2);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(242, 29);
            txtSearch.TabIndex = 2;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(44, 67);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(47, 17);
            label3.TabIndex = 3;
            label3.Text = "Search";
            // 
            // grid1
            // 
            grid1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grid1.Location = new Point(44, 101);
            grid1.Margin = new Padding(2);
            grid1.Name = "grid1";
            grid1.RowTemplate.Height = 25;
            grid1.Size = new Size(478, 312);
            grid1.TabIndex = 4;
            grid1.CellContentClick += grid1_CellContentClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(558, 23);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(194, 25);
            label4.TabIndex = 5;
            label4.Text = "Borrower Information";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(558, 68);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(71, 17);
            label5.TabIndex = 6;
            label5.Text = "User name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(558, 101);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(68, 17);
            label6.TabIndex = 6;
            label6.Text = "First name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(558, 140);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(70, 17);
            label7.TabIndex = 6;
            label7.Text = "Last Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(558, 173);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(35, 17);
            label8.TabIndex = 6;
            label8.Text = "Date";
            // 
            // txtusername
            // 
            txtusername.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtusername.Location = new Point(686, 68);
            txtusername.Margin = new Padding(2);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(156, 29);
            txtusername.TabIndex = 7;
            // 
            // txtfirstname
            // 
            txtfirstname.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtfirstname.Location = new Point(686, 101);
            txtfirstname.Margin = new Padding(2);
            txtfirstname.Name = "txtfirstname";
            txtfirstname.Size = new Size(156, 29);
            txtfirstname.TabIndex = 7;
            // 
            // txtlastname
            // 
            txtlastname.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtlastname.Location = new Point(686, 134);
            txtlastname.Margin = new Padding(2);
            txtlastname.Name = "txtlastname";
            txtlastname.Size = new Size(156, 29);
            txtlastname.TabIndex = 7;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(558, 224);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(158, 25);
            label9.TabIndex = 8;
            label9.Text = "Book Information";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(558, 264);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(117, 17);
            label10.TabIndex = 9;
            label10.Text = "Accession Number";
            // 
            // txtaccessionnumber
            // 
            txtaccessionnumber.Location = new Point(686, 261);
            txtaccessionnumber.Margin = new Padding(2);
            txtaccessionnumber.Name = "txtaccessionnumber";
            txtaccessionnumber.Size = new Size(155, 25);
            txtaccessionnumber.TabIndex = 10;
            // 
            // txttitle
            // 
            txttitle.Location = new Point(686, 290);
            txttitle.Margin = new Padding(2);
            txttitle.Name = "txttitle";
            txttitle.Size = new Size(155, 25);
            txttitle.TabIndex = 10;
            // 
            // txtauthor
            // 
            txtauthor.Location = new Point(686, 319);
            txtauthor.Margin = new Padding(2);
            txtauthor.Name = "txtauthor";
            txtauthor.Size = new Size(155, 25);
            txtauthor.TabIndex = 10;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(561, 293);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(32, 17);
            label11.TabIndex = 9;
            label11.Text = "Title";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(561, 322);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(47, 17);
            label12.TabIndex = 9;
            label12.Text = "Author";
            // 
            // txtyrpublished
            // 
            txtyrpublished.Location = new Point(686, 351);
            txtyrpublished.Margin = new Padding(2);
            txtyrpublished.Name = "txtyrpublished";
            txtyrpublished.Size = new Size(155, 25);
            txtyrpublished.TabIndex = 10;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(561, 351);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(93, 17);
            label13.TabIndex = 9;
            label13.Text = "Year Published";
            // 
            // btnborrow
            // 
            btnborrow.Location = new Point(767, 390);
            btnborrow.Name = "btnborrow";
            btnborrow.Size = new Size(75, 23);
            btnborrow.TabIndex = 11;
            btnborrow.Text = "Borrow";
            btnborrow.UseVisualStyleBackColor = true;
            btnborrow.Click += btnborrow_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(932, 24);
            menuStrip1.TabIndex = 12;
            menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(52, 20);
            homeToolStripMenuItem.Text = "Home";
            homeToolStripMenuItem.Click += homeToolStripMenuItem_Click;
            // 
            // txtdate
            // 
            txtdate.Location = new Point(656, 173);
            txtdate.Name = "txtdate";
            txtdate.Size = new Size(244, 25);
            txtdate.TabIndex = 13;
            // 
            // borrow
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(932, 473);
            Controls.Add(txtdate);
            Controls.Add(btnborrow);
            Controls.Add(txtyrpublished);
            Controls.Add(txtauthor);
            Controls.Add(txttitle);
            Controls.Add(txtaccessionnumber);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(txtlastname);
            Controls.Add(txtfirstname);
            Controls.Add(txtusername);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(grid1);
            Controls.Add(label3);
            Controls.Add(txtSearch);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            MainMenuStrip = menuStrip1;
            Name = "borrow";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "borrow";
            Load += borrow_Load;
            ((System.ComponentModel.ISupportInitialize)grid1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtSearch;
        private Label label3;
        private DataGridView grid1;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtusername;
        private TextBox txtfirstname;
        private TextBox txtlastname;
        private Label label9;
        private Label label10;
        private TextBox txtaccessionnumber;
        private TextBox txttitle;
        private TextBox txtauthor;
        private Label label11;
        private Label label12;
        private TextBox txtyrpublished;
        private Label label13;
        private Button btnborrow;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem homeToolStripMenuItem;
        private DateTimePicker txtdate;
    }
}