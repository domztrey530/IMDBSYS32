﻿namespace usersignup
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            chkshow = new CheckBox();
            btnfpass = new Button();
            txtreveal = new TextBox();
            BtnLogin = new Button();
            btnsignup = new Button();
            label2 = new Label();
            loginuser = new Label();
            textpassword = new TextBox();
            txtusername = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkshow);
            groupBox1.Controls.Add(btnfpass);
            groupBox1.Controls.Add(txtreveal);
            groupBox1.Controls.Add(BtnLogin);
            groupBox1.Controls.Add(btnsignup);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(loginuser);
            groupBox1.Controls.Add(textpassword);
            groupBox1.Controls.Add(txtusername);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(425, 90);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(363, 332);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Login";
            // 
            // chkshow
            // 
            chkshow.AutoSize = true;
            chkshow.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            chkshow.Location = new Point(118, 136);
            chkshow.Name = "chkshow";
            chkshow.Size = new Size(55, 17);
            chkshow.TabIndex = 5;
            chkshow.Text = "Show";
            chkshow.UseVisualStyleBackColor = true;
            chkshow.CheckedChanged += chkshow_CheckedChanged;
            // 
            // btnfpass
            // 
            btnfpass.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnfpass.Location = new Point(24, 199);
            btnfpass.Name = "btnfpass";
            btnfpass.Size = new Size(132, 29);
            btnfpass.TabIndex = 4;
            btnfpass.Text = "Forgot Password";
            btnfpass.UseVisualStyleBackColor = true;
            btnfpass.Click += btnfpass_Click;
            // 
            // txtreveal
            // 
            txtreveal.Location = new Point(162, 199);
            txtreveal.Name = "txtreveal";
            txtreveal.Size = new Size(170, 29);
            txtreveal.TabIndex = 3;
            // 
            // BtnLogin
            // 
            BtnLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            BtnLogin.Location = new Point(185, 159);
            BtnLogin.Name = "BtnLogin";
            BtnLogin.Size = new Size(75, 34);
            BtnLogin.TabIndex = 2;
            BtnLogin.Text = "Login";
            BtnLogin.UseVisualStyleBackColor = true;
            BtnLogin.Click += BtnLogin_Click;
            // 
            // btnsignup
            // 
            btnsignup.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnsignup.Location = new Point(64, 159);
            btnsignup.Name = "btnsignup";
            btnsignup.Size = new Size(76, 34);
            btnsignup.TabIndex = 2;
            btnsignup.Text = "Sign Up";
            btnsignup.UseVisualStyleBackColor = true;
            btnsignup.Click += btnsignup_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(36, 107);
            label2.Name = "label2";
            label2.Size = new Size(76, 21);
            label2.TabIndex = 1;
            label2.Text = "Password";
            // 
            // loginuser
            // 
            loginuser.AutoSize = true;
            loginuser.Location = new Point(36, 50);
            loginuser.Name = "loginuser";
            loginuser.Size = new Size(81, 21);
            loginuser.TabIndex = 1;
            loginuser.Text = "Username";
            // 
            // textpassword
            // 
            textpassword.Location = new Point(118, 99);
            textpassword.Name = "textpassword";
            textpassword.Size = new Size(167, 29);
            textpassword.TabIndex = 0;
            textpassword.UseSystemPasswordChar = true;
            // 
            // txtusername
            // 
            txtusername.Location = new Point(118, 47);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(167, 29);
            txtusername.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.final_logo;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(29, 90);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(333, 332);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(205, 27);
            label1.Name = "label1";
            label1.Size = new Size(395, 47);
            label1.TabIndex = 2;
            label1.Text = "NSDAP Library System";
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            DoubleBuffered = true;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Button BtnLogin;
        private Button btnsignup;
        private Label label2;
        private Label loginuser;
        private TextBox textpassword;
        private TextBox txtusername;
        private Button btnfpass;
        private TextBox txtreveal;
        private CheckBox chkshow;
        private PictureBox pictureBox1;
        private Label label1;
    }
}