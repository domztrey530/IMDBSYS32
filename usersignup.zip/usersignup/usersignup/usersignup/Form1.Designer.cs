﻿namespace usersignup
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtfname = new TextBox();
            txtlname = new TextBox();
            txtuser = new TextBox();
            txtpass = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btncancel = new Button();
            btnregister = new Button();
            txtconfirmpass = new TextBox();
            label5 = new Label();
            chkshow = new CheckBox();
            groupBox1 = new GroupBox();
            chkshow2 = new CheckBox();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtfname
            // 
            txtfname.BackColor = SystemColors.Menu;
            txtfname.Location = new Point(159, 31);
            txtfname.Name = "txtfname";
            txtfname.Size = new Size(203, 29);
            txtfname.TabIndex = 0;
            // 
            // txtlname
            // 
            txtlname.BackColor = SystemColors.Menu;
            txtlname.Location = new Point(159, 87);
            txtlname.Name = "txtlname";
            txtlname.Size = new Size(203, 29);
            txtlname.TabIndex = 0;
            // 
            // txtuser
            // 
            txtuser.BackColor = SystemColors.Menu;
            txtuser.Location = new Point(159, 138);
            txtuser.Name = "txtuser";
            txtuser.Size = new Size(203, 29);
            txtuser.TabIndex = 0;
            // 
            // txtpass
            // 
            txtpass.BackColor = SystemColors.Menu;
            txtpass.Location = new Point(159, 191);
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(203, 29);
            txtpass.TabIndex = 0;
            txtpass.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(67, 34);
            label1.Name = "label1";
            label1.Size = new Size(86, 21);
            label1.TabIndex = 1;
            label1.Text = "First Name";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(69, 87);
            label2.Name = "label2";
            label2.Size = new Size(84, 21);
            label2.TabIndex = 1;
            label2.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(72, 141);
            label3.Name = "label3";
            label3.Size = new Size(81, 21);
            label3.TabIndex = 1;
            label3.Text = "Username";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(77, 191);
            label4.Name = "label4";
            label4.Size = new Size(76, 21);
            label4.TabIndex = 1;
            label4.Text = "Password";
            // 
            // btncancel
            // 
            btncancel.BackColor = SystemColors.ControlText;
            btncancel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btncancel.Location = new Point(101, 314);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(87, 42);
            btncancel.TabIndex = 2;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += btncancel_Click;
            // 
            // btnregister
            // 
            btnregister.BackColor = SystemColors.ControlText;
            btnregister.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnregister.Location = new Point(216, 314);
            btnregister.Name = "btnregister";
            btnregister.Size = new Size(83, 42);
            btnregister.TabIndex = 2;
            btnregister.Text = "Sign Up";
            btnregister.UseVisualStyleBackColor = false;
            btnregister.Click += btnregister_Click;
            // 
            // txtconfirmpass
            // 
            txtconfirmpass.BackColor = SystemColors.Menu;
            txtconfirmpass.Location = new Point(159, 251);
            txtconfirmpass.Name = "txtconfirmpass";
            txtconfirmpass.Size = new Size(203, 29);
            txtconfirmpass.TabIndex = 0;
            txtconfirmpass.UseSystemPasswordChar = true;
            txtconfirmpass.TextChanged += txtconfirmpass_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(16, 251);
            label5.Name = "label5";
            label5.Size = new Size(137, 21);
            label5.TabIndex = 1;
            label5.Text = "Confirm Password";
            // 
            // chkshow
            // 
            chkshow.AutoSize = true;
            chkshow.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            chkshow.Location = new Point(159, 226);
            chkshow.Name = "chkshow";
            chkshow.Size = new Size(55, 19);
            chkshow.TabIndex = 3;
            chkshow.Text = "Show";
            chkshow.UseVisualStyleBackColor = true;
            chkshow.CheckedChanged += chkshow_CheckedChanged;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ControlText;
            groupBox1.Controls.Add(chkshow2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btncancel);
            groupBox1.Controls.Add(btnregister);
            groupBox1.Controls.Add(chkshow);
            groupBox1.Controls.Add(txtfname);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtconfirmpass);
            groupBox1.Controls.Add(txtlname);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtuser);
            groupBox1.Controls.Add(txtpass);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(202, 65);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(402, 373);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Sign Up";
            // 
            // chkshow2
            // 
            chkshow2.AutoSize = true;
            chkshow2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            chkshow2.Location = new Point(159, 289);
            chkshow2.Name = "chkshow2";
            chkshow2.Size = new Size(55, 19);
            chkshow2.TabIndex = 4;
            chkshow2.Text = "Show";
            chkshow2.UseVisualStyleBackColor = true;
            chkshow2.CheckedChanged += chkshow2_CheckedChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(269, 15);
            label6.Name = "label6";
            label6.Size = new Size(395, 47);
            label6.TabIndex = 4;
            label6.Text = "NSDAP Library System";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources._5146394;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(218, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(51, 50);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(label6);
            Controls.Add(groupBox1);
            ForeColor = Color.FromArgb(255, 255, 128);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sign Up";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtfname;
        private TextBox txtlname;
        private TextBox txtuser;
        private TextBox txtpass;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btncancel;
        private Button btnregister;
        private TextBox txtconfirmpass;
        private Label label5;
        private CheckBox chkshow;
        private GroupBox groupBox1;
        private Label label6;
        private PictureBox pictureBox1;
        private CheckBox chkshow2;
    }
}