﻿namespace usersignup
{
    partial class forgotpass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btncancel = new Button();
            chkshow4 = new CheckBox();
            chkshow3 = new CheckBox();
            btnreset = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtrstconpass = new TextBox();
            txtrstnewpass = new TextBox();
            txtrstuname = new TextBox();
            label4 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ControlText;
            groupBox1.Controls.Add(btncancel);
            groupBox1.Controls.Add(chkshow4);
            groupBox1.Controls.Add(chkshow3);
            groupBox1.Controls.Add(btnreset);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtrstconpass);
            groupBox1.Controls.Add(txtrstnewpass);
            groupBox1.Controls.Add(txtrstuname);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.ForeColor = Color.FromArgb(255, 255, 128);
            groupBox1.Location = new Point(199, 72);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(406, 301);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Reset Password";
            // 
            // btncancel
            // 
            btncancel.BackColor = SystemColors.ControlText;
            btncancel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btncancel.Location = new Point(89, 242);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(87, 42);
            btncancel.TabIndex = 10;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += btncancel_Click;
            // 
            // chkshow4
            // 
            chkshow4.AutoSize = true;
            chkshow4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            chkshow4.Location = new Point(176, 208);
            chkshow4.Name = "chkshow4";
            chkshow4.Size = new Size(55, 19);
            chkshow4.TabIndex = 9;
            chkshow4.Text = "Show";
            chkshow4.UseVisualStyleBackColor = true;
            chkshow4.CheckedChanged += chkshow4_CheckedChanged;
            // 
            // chkshow3
            // 
            chkshow3.AutoSize = true;
            chkshow3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            chkshow3.Location = new Point(176, 152);
            chkshow3.Name = "chkshow3";
            chkshow3.Size = new Size(55, 19);
            chkshow3.TabIndex = 8;
            chkshow3.Text = "Show";
            chkshow3.UseVisualStyleBackColor = true;
            chkshow3.CheckedChanged += chkshow3_CheckedChanged;
            // 
            // btnreset
            // 
            btnreset.BackColor = SystemColors.ControlText;
            btnreset.Location = new Point(231, 242);
            btnreset.Name = "btnreset";
            btnreset.Size = new Size(104, 44);
            btnreset.TabIndex = 7;
            btnreset.Text = "Reset";
            btnreset.UseVisualStyleBackColor = false;
            btnreset.Click += btnreset_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 176);
            label3.Name = "label3";
            label3.Size = new Size(154, 21);
            label3.TabIndex = 6;
            label3.Text = "Confirmed Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(58, 120);
            label2.Name = "label2";
            label2.Size = new Size(112, 21);
            label2.TabIndex = 5;
            label2.Text = "New Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(89, 65);
            label1.Name = "label1";
            label1.Size = new Size(81, 21);
            label1.TabIndex = 4;
            label1.Text = "Username";
            // 
            // txtrstconpass
            // 
            txtrstconpass.Location = new Point(176, 173);
            txtrstconpass.Name = "txtrstconpass";
            txtrstconpass.Size = new Size(213, 29);
            txtrstconpass.TabIndex = 2;
            // 
            // txtrstnewpass
            // 
            txtrstnewpass.Location = new Point(176, 117);
            txtrstnewpass.Name = "txtrstnewpass";
            txtrstnewpass.Size = new Size(213, 29);
            txtrstnewpass.TabIndex = 1;
            // 
            // txtrstuname
            // 
            txtrstuname.Location = new Point(176, 57);
            txtrstuname.Name = "txtrstuname";
            txtrstuname.Size = new Size(213, 29);
            txtrstuname.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ControlText;
            label4.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(255, 255, 128);
            label4.Location = new Point(288, 24);
            label4.Name = "label4";
            label4.Size = new Size(239, 45);
            label4.TabIndex = 1;
            label4.Text = "Reset Password";
            // 
            // forgotpass
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlText;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Name = "forgotpass";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reset Password";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private TextBox txtrstconpass;
        private TextBox txtrstnewpass;
        private TextBox txtrstuname;
        private Label label2;
        private Label label3;
        private Button btnreset;
        private CheckBox chkshow3;
        private CheckBox chkshow4;
        private Button btncancel;
        private Label label4;
    }
}