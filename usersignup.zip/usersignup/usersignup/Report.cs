﻿using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace usersignup
{
    public partial class Report : Form
    {
        Thread HomeFromReport;
        //private DataGridViewPrinter dataGridViewPrinter;
        public Report()
        {
            InitializeComponent();
            // dataGridViewPrinter = new DataGridViewPrinter(dataGridView1);
        }
        public void BackHome(object obj)
        {
            Application.Run(new home());
        }

        private void loadDatagrid()
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT Backup_Records.username, CONCAT(firstname, ' ', lastname) AS Name," +
                    " Backup_Records.Accession_number, Backup_Records.Title,\r\nBackup_Records.Date_Borrowed," +
                    " Backup_Records_Returned_Date.Returned_Date  \r\nFROM Backup_Records \r\nINNER JOIN Backup_Records_Returned_Date \r\nON Backup_Records.username = Backup_Records_Returned_Date.username;", con);

                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                dataGridView1.DataSource = tab;

                con.Close();
            }


        }

        private void Report_Load(object sender, EventArgs e)
        {
            loadDatagrid();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-0M2VQGUQ\\SQLEXPRESS;Initial Catalog=userregcs;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT Backup_Records.username, CONCAT(firstname, ' ', lastname) AS Name, Backup_Records.Accession_number, Backup_Records.Title,\r\nBackup_Records.Date_Borrowed," +
                    " Backup_Records_Returned_Date.Returned_Date  \r\nFROM Backup_Records \r\nINNER JOIN Backup_Records_Returned_Date \r\nON Backup_Records.username = Backup_Records_Returned_Date.username where Accession_number like'%" + txtSearch.Text + "%'", con);


                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();

                adap.Fill(tab);
                dataGridView1.DataSource = tab;

                con.Close();

            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            HomeFromReport = new Thread(BackHome);
            HomeFromReport.SetApartmentState(ApartmentState.STA);
            HomeFromReport.Start();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font titleFont = new Font("Arial", 16, FontStyle.Bold);
            Font printFont = new Font("Arial", 10);
            SolidBrush printBrush = new SolidBrush(Color.Black);

            float yPosition = 20;
            float xPosition = 20;

            string title = "My Print Document";
            SizeF titleSize = e.Graphics.MeasureString(title, titleFont);
            RectangleF titleRect = new RectangleF(xPosition, yPosition, titleSize.Width, titleSize.Height);
            e.Graphics.DrawRectangle(Pens.Black, titleRect.X, titleRect.Y, titleRect.Width, titleRect.Height);
            e.Graphics.DrawString(title, titleFont, printBrush, titleRect);

            yPosition += titleRect.Height + 10;
            xPosition = 20;

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    string cellValue = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    e.Graphics.DrawString(cellValue, printFont, printBrush, xPosition, yPosition);
                    xPosition += dataGridView1.Columns[j].Width;
                }

                yPosition += printFont.GetHeight();
                xPosition = 20;
            }
        }


        private void printbutton_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();

            pd.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = pd;
            ppd.ShowDialog();
        }
    }
}