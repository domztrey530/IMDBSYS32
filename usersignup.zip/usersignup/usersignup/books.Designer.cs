﻿namespace usersignup
{
    partial class books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txttitle = new TextBox();
            label1 = new Label();
            txtauthor = new TextBox();
            txtyrpublished = new TextBox();
            btnadd = new Button();
            btnedit = new Button();
            btndelete = new Button();
            groupBox1 = new GroupBox();
            txtSearch = new TextBox();
            grid1 = new DataGridView();
            txtno = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            menuStrip1 = new MenuStrip();
            homeToolStripMenuItem = new ToolStripMenuItem();
            label6 = new Label();
            txtquantity = new TextBox();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grid1).BeginInit();
            menuStrip1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // txttitle
            // 
            txttitle.CausesValidation = false;
            txttitle.ForeColor = SystemColors.MenuText;
            txttitle.Location = new Point(155, 81);
            txttitle.Name = "txttitle";
            txttitle.Size = new Size(259, 23);
            txttitle.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Historic", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(71, 22);
            label1.Name = "label1";
            label1.Size = new Size(126, 50);
            label1.TabIndex = 1;
            label1.Text = "Books";
            // 
            // txtauthor
            // 
            txtauthor.ForeColor = SystemColors.MenuText;
            txtauthor.Location = new Point(155, 122);
            txtauthor.Name = "txtauthor";
            txtauthor.Size = new Size(259, 23);
            txtauthor.TabIndex = 0;
            // 
            // txtyrpublished
            // 
            txtyrpublished.ForeColor = SystemColors.MenuText;
            txtyrpublished.Location = new Point(155, 208);
            txtyrpublished.Name = "txtyrpublished";
            txtyrpublished.Size = new Size(259, 23);
            txtyrpublished.TabIndex = 0;
            // 
            // btnadd
            // 
            btnadd.Location = new Point(91, 260);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(82, 39);
            btnadd.TabIndex = 2;
            btnadd.Text = "Add";
            btnadd.UseVisualStyleBackColor = true;
            btnadd.Click += btnadd_Click;
            // 
            // btnedit
            // 
            btnedit.Location = new Point(196, 260);
            btnedit.Name = "btnedit";
            btnedit.Size = new Size(75, 39);
            btnedit.TabIndex = 2;
            btnedit.Text = "Edit";
            btnedit.UseVisualStyleBackColor = true;
            btnedit.Click += btnedit_Click;
            // 
            // btndelete
            // 
            btndelete.Location = new Point(292, 260);
            btndelete.Name = "btndelete";
            btndelete.Size = new Size(75, 39);
            btndelete.TabIndex = 2;
            btndelete.Text = "Delete";
            btndelete.UseVisualStyleBackColor = true;
            btndelete.Click += btndelete_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtSearch);
            groupBox1.Controls.Add(grid1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(71, 399);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(669, 402);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Search/View";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(16, 28);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(251, 29);
            txtSearch.TabIndex = 1;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // grid1
            // 
            grid1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grid1.Location = new Point(16, 63);
            grid1.Name = "grid1";
            grid1.RowTemplate.Height = 25;
            grid1.Size = new Size(637, 333);
            grid1.TabIndex = 0;
            grid1.CellContentClick += grid1_CellContentClick;
            // 
            // txtno
            // 
            txtno.ForeColor = SystemColors.MenuText;
            txtno.Location = new Point(155, 39);
            txtno.Name = "txtno";
            txtno.Size = new Size(259, 23);
            txtno.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(9, 41);
            label2.Name = "label2";
            label2.Size = new Size(140, 21);
            label2.TabIndex = 9;
            label2.Text = "Accession Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(110, 83);
            label3.Name = "label3";
            label3.Size = new Size(39, 21);
            label3.TabIndex = 9;
            label3.Text = "Title";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(91, 124);
            label4.Name = "label4";
            label4.Size = new Size(58, 21);
            label4.TabIndex = 9;
            label4.Text = "Author";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(37, 208);
            label5.Name = "label5";
            label5.Size = new Size(112, 21);
            label5.TabIndex = 9;
            label5.Text = "Year Published";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(785, 24);
            menuStrip1.TabIndex = 10;
            menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(52, 20);
            homeToolStripMenuItem.Text = "Home";
            homeToolStripMenuItem.Click += homeToolStripMenuItem_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(79, 167);
            label6.Name = "label6";
            label6.Size = new Size(70, 21);
            label6.TabIndex = 11;
            label6.Text = "Quantity";
            // 
            // txtquantity
            // 
            txtquantity.Location = new Point(156, 165);
            txtquantity.Name = "txtquantity";
            txtquantity.Size = new Size(258, 23);
            txtquantity.TabIndex = 12;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtquantity);
            groupBox2.Controls.Add(btndelete);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(btnedit);
            groupBox2.Controls.Add(txtno);
            groupBox2.Controls.Add(btnadd);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtyrpublished);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(txttitle);
            groupBox2.Controls.Add(txtauthor);
            groupBox2.Location = new Point(188, 75);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(459, 318);
            groupBox2.TabIndex = 13;
            groupBox2.TabStop = false;
            groupBox2.Text = "Books";
            // 
            // books
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(785, 808);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "books";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "books";
            Load += books_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grid1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txttitle;
        private Label label1;
        private TextBox txtauthor;
        private TextBox txtyrpublished;
        private Button btnadd;
        private Button btnedit;
        private Button btndelete;
        private GroupBox groupBox1;
        private TextBox txtSearch;
        private DataGridView grid1;
        private TextBox txtno;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem homeToolStripMenuItem;
        private Label label6;
        private TextBox txtquantity;
        private GroupBox groupBox2;
    }
}